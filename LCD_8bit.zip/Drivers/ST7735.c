#include "ST7735.h"

_lcd_dev lcddev;

//  д����: DC = 0
void LCD_WR_DATA(uint8_t data)
{
    LCD_DC_S; // ����-����
    LCD_CS_C;
    LCD_DATA(data);
    LCD_WRB_C;
    LCD_WRB_S;
    LCD_CS_S;
}
// д����: DC = 1
void LCD_WR_REG(uint8_t data)
{
    LCD_DC_C; // ����-����
    LCD_CS_C;
    LCD_DATA(data);
    LCD_WRB_C;
    LCD_WRB_S;
    LCD_CS_S;
}

// дʮ��λ����
void lcd_write_data_u16(uint16_t data)
{
    LCD_WRB_C;
    LCD_DATA(data >> 8);
    LCD_WRB_S;

    LCD_WRB_C;
    LCD_DATA(data & 0xff);
    LCD_WRB_S;
}
// ��λ
void lcd_reset()
{
    LCD_RES_S;      // RST��������
    HAL_Delay(120); // Delay(10000); // ��λ��ȴ�120ms
    LCD_RES_C;      // RST��������
    HAL_Delay(120); // Delay(100);    // Ҫ�����10uS
    LCD_RES_S;      // RST��������
    HAL_Delay(120); // Delay(30000); // ��λ��ȴ�120ms
}

// dir:����ѡ�� 	0-0����ת��1-180����ת��2-270����ת��3-90����ת
void LCD_Display_Dir(uint8_t dir)
{
    lcddev.wramcmd = 0X2C;
    lcddev.setxcmd = 0X2A;
    lcddev.setycmd = 0X2B;
    if (dir == 0 || dir == 1) // ����
    {
        lcddev.dir = 0; // ����
        lcddev.width = LCD_WIDTH;
        lcddev.height = LCD_HEIGHT;

        if (dir == 0) // 0-0����ת
        {
            LCD_WR_REG(0x36);
            LCD_WR_DATA((0 << 3) | (1 << 7) | (1 << 6) | (0 << 5));
        }
        else // 1-180����ת
        {
            LCD_WR_REG(0x36);
            LCD_WR_DATA((0 << 3) | (0 << 7) | (0 << 6) | (0 << 5));
        }
    }
    else if (dir == 2 || dir == 3)
    {

        lcddev.dir = 1; // ����
        lcddev.width = LCD_HEIGHT;//�˴�������ת�ֱ���
        lcddev.height = LCD_WIDTH;

        if (dir == 2) // 2-270����ת
        {
            LCD_WR_REG(0x36);
            LCD_WR_DATA((0 << 3) | (0 << 7) | (1 << 6) | (1 << 5));
        }
        else // 3-90����ת
        {
            LCD_WR_REG(0x36);
            LCD_WR_DATA((0 << 3) | (1 << 7) | (0 << 6) | (1 << 5));
        }
    }

    // ������ʾ����
    LCD_WR_REG(lcddev.setxcmd);
    LCD_WR_DATA(0);
    LCD_WR_DATA(0);
    LCD_WR_DATA((lcddev.width - 1) >> 8);
    LCD_WR_DATA((lcddev.width - 1) & 0XFF);
    LCD_WR_REG(lcddev.setycmd);
    LCD_WR_DATA(0);
    LCD_WR_DATA(0);
    LCD_WR_DATA((lcddev.height - 1) >> 8);
    LCD_WR_DATA((lcddev.height - 1) & 0XFF);
}

void lcd_init(void)
{

    lcd_reset(); // Reset before LCD Init.
    LCD_RDB_S;

    //************* Start Initial Sequence **********//
    HAL_Delay(120); // ms

    LCD_WR_REG(0x11); // Sleep out

    HAL_Delay(120); // delay_ms 120ms

    LCD_WR_REG(0xB1);  // In normal mode
    LCD_WR_DATA(0x00); // frame rate=85.3Hz
    LCD_WR_DATA(0x2C);
    LCD_WR_DATA(0x2B);

    LCD_WR_REG(0xB2); // In Idle mode
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x01);
    LCD_WR_DATA(0x01);

    LCD_WR_REG(0xB3); // In partial mode
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x01);
    LCD_WR_DATA(0x01);
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x01);
    LCD_WR_DATA(0x01);

    LCD_WR_REG(0xB4); // DOT inversion Display Inversion Control
    LCD_WR_DATA(0x03);

    LCD_WR_REG(0xB9); // In normal mode
    LCD_WR_DATA(0xFF);
    LCD_WR_DATA(0x83);
    LCD_WR_DATA(0x47);

    LCD_WR_REG(0xC0); // VRH: Set the GVDD
    LCD_WR_DATA(0xA2);
    LCD_WR_DATA(0x02);
    LCD_WR_DATA(0x84);

    LCD_WR_REG(0xC1);  // set VGH/ VGL
    LCD_WR_DATA(0x02); //??02 VGH=16.6 VGL=-7.5  00 VGH=11.6 VGL=-7.5  06 VGH=16.6  VGL=-10

    LCD_WR_REG(0xC2); // APA: adjust the operational amplifier DCA: adjust the booster Voltage
    LCD_WR_DATA(0x0A);
    LCD_WR_DATA(0x00);

    LCD_WR_REG(0xC3); // In Idle mode (8-colors)
    LCD_WR_DATA(0x8A);
    LCD_WR_DATA(0x2A);

    LCD_WR_REG(0xC4); // In partial mode + Full color
    LCD_WR_DATA(0x8A);
    LCD_WR_DATA(0xEE);

    LCD_WR_REG(0xC5); // VCOM
    LCD_WR_DATA(0x09);

    LCD_WR_REG(0x20); // Display inversion

    LCD_WR_REG(0xC7);
    LCD_WR_DATA(0x10);

    LCD_WR_REG(0x36);  // MX, MY, RGB mode
    LCD_WR_DATA(0xC0); // 08

    LCD_WR_REG(0xE0);
    LCD_WR_DATA(0x0C);
    LCD_WR_DATA(0x1C);
    LCD_WR_DATA(0x1B);
    LCD_WR_DATA(0x1A);
    LCD_WR_DATA(0x2F);
    LCD_WR_DATA(0x28);
    LCD_WR_DATA(0x20);
    LCD_WR_DATA(0x24);
    LCD_WR_DATA(0x23);
    LCD_WR_DATA(0x22);
    LCD_WR_DATA(0x2A);
    LCD_WR_DATA(0x36);
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x05);
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x10);

    LCD_WR_REG(0xE1);
    LCD_WR_DATA(0x0C);
    LCD_WR_DATA(0x1A);
    LCD_WR_DATA(0x1A);
    LCD_WR_DATA(0x1A);
    LCD_WR_DATA(0x2E);
    LCD_WR_DATA(0x27);
    LCD_WR_DATA(0x21);
    LCD_WR_DATA(0x24);
    LCD_WR_DATA(0x24);
    LCD_WR_DATA(0x22);
    LCD_WR_DATA(0x2A);
    LCD_WR_DATA(0x35);
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x05);
    LCD_WR_DATA(0x00);
    LCD_WR_DATA(0x10);

    LCD_WR_REG(0x35); // 65k mode
    LCD_WR_DATA(0x00);

    LCD_WR_REG(0x3A); // 65k mode
    LCD_WR_DATA(0x05);

    LCD_WR_REG(0x29); // Display on
    // LCD_Display_Dir(0);
}

// д����Ļ��ַ����
void lcd_write_address(uint8_t x_start, uint8_t y_start, uint8_t x_end, uint8_t y_end)
{

    LCD_WR_REG(0x2a); // �����е�ַָ��
    LCD_WR_DATA(x_start >> 8);
    LCD_WR_DATA(x_start & 0xff);
    LCD_WR_DATA(x_end >> 8);
    LCD_WR_DATA(x_end & 0xff);

    LCD_WR_REG(0x2b); // �����е�ַָ��
    LCD_WR_DATA(y_start >> 8);
    LCD_WR_DATA(y_start & 0xff);
    LCD_WR_DATA(y_end >> 8);
    LCD_WR_DATA(y_end & 0xff);

    LCD_WR_REG(0x2c); // д������ָ��
}

// ��㺯��
void lcd_set_point_color(uint8_t x_point, uint8_t y_point, uint16_t color)
{

    lcd_write_address(x_point, y_point, x_point, y_point);
    LCD_DC_S;
    LCD_CS_C; // ����-Ƭѡ
    lcd_write_data_u16(color);
    LCD_CS_S; // ����-Ƭѡ
}

// ������ɫ���
void lcd_set_area_color(uint8_t x_start, uint8_t y_start, uint8_t x_end, uint8_t y_end, uint16_t color)
{
    uint8_t i, j;
    uint8_t x_len, y_len;
    lcd_write_address(x_start, y_start, x_end, y_end);
    // �����������ĳ��ȺͿ��ȣ��յ�������������+1
    x_len = x_end - x_start + 1; // ����x����ĳ���
    y_len = y_end - y_start + 1; // ����y����ĳ���

    LCD_CS_C; // ����-Ƭѡ
    LCD_DC_S; // ����-����

    for (i = 0; i < y_len; i++)
    {
        for (j = 0; j < x_len; j++)
        {
            LCD_WRB_C;
            LCD_DATA(color >> 8);
            LCD_WRB_S;

            LCD_WRB_C;
            LCD_DATA(color & 0xff);
            LCD_WRB_S;
            // �������ݵ�Ч���������������ִ�д����϶࣬��������˷�ʱ�䣬���ô������
            //  lcd_write_data_u16(color);
        }
    }
    LCD_CS_S; // ����-Ƭѡ
}

// ȫ����ɫ���
void lcd_set_color(uint16_t color)
{
    if(lcddev.dir==0)
    {
        lcd_set_area_color(0, 0, LCD_WIDTH-1, LCD_HEIGHT-1, color);
    }
    else
    {
        lcd_set_area_color(0, 0, LCD_HEIGHT-1, LCD_WIDTH-1, color);
    }
}
